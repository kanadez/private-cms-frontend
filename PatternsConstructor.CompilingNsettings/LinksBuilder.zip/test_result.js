{"aaData": [
    ["Result# 1", "<img src='img/folder.png' style='cursor:pointer' alt='' />", 1],
    ["Result# 2", "<img src='img/folder.png' style='cursor:pointer' alt='' />", 2],
    ["Result# 3", "<img src='img/folder.png' style='cursor:pointer' alt='' />", 3],
    ["Result# 4", "<img src='img/folder.png' style='cursor:pointer' alt='' />", 4],
    ["Result# 5", "<img src='img/folder.png' style='cursor:pointer' alt='' />", 5],
    ["Result# 6", "<img src='img/folder.png' style='cursor:pointer' alt='' />", 6],
    ["Result# 7", "<img src='img/folder.png' style='cursor:pointer' alt='' />", 7]
]}